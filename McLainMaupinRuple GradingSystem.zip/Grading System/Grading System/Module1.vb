﻿Module Module1
    'Mercy
    Public connectionString As String = "Data Source = DESKTOP-II3CLP1\SQLEXPRESS;Initial Catalog=LPA;Integrated Security=true"
    'Hannah
    'Public connectionString As String = "Data Source = MIS-W10-030\SQLEXPRESS;Initial Catalog=LPA;Integrated Security=true"
    'Andrew
    'Public connectionString As String = "Data Source = DESKTOP-6VVI9NG\SQLEXPRESS;Initial Catalog=LPA;Integrated Security=true"

End Module
